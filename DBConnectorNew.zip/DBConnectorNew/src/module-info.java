/**
 * 
 */
/**
 * 
 */
module DBConnectorNew {
	requires java.sql;
	requires fdb.java;
}