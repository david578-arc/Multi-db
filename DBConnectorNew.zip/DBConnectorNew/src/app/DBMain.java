package app;

import config.DBConfig;
import config.SqlQuery;
import connection.ConnectionManager;
import query.QueryHandler;
import com.apple.foundationdb.Database;
import com.apple.foundationdb.FDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import java.util.Map;

public class DBMain {
    public static void main(String[] args) throws Exception {
    	System.out.print("bg");
        DBConfig dbConfig = DBConfig.loadFromXml("src/config/db-config.xml");
        ConnectionManager connectionManager = new ConnectionManager(dbConfig);
        QueryHandler queryHandler = new QueryHandler(connectionManager);
        SqlQuery sqlQueries = new SqlQuery("src/config/sql.properties");

        String createTableSql = sqlQueries.get("thirdDB.createTable");
        String insertSql = sqlQueries.get("thirdDB.insertEmployee");
        String selectSql = sqlQueries.get("thirdDB.selectAllEmployees");

        queryHandler.executeUpdate("thirdDB",createTableSql);
        queryHandler.executeUpdate("thirdDB",insertSql,"David","Software development",65000.0);
        queryHandler.executeUpdate("thirdDB",insertSql,"sam","Ml",78000.0);
        DBConfig.DbEntry db = dbConfig.getDbEntry("secondDB");
       System.load("C:\\Program Files\\foundationdb\\bin\\fdb_c.dll\\");
      FDB fdb = FDB.selectAPIVersion(730);

   try (Database db1 = fdb.open()) {
       db1.run(tr -> {
            tr.set("name".getBytes(), "David".getBytes());
            return null;
          });
          String value = db1.run(tr -> {
               byte[] data = tr.get("name".getBytes()).join();
               return new String(data);
            });

            System.out.println("Value: " + value);
        }

        List<Map<String, Object>> rows = queryHandler.executeSelect("thirdDB", selectSql);
        System.out.println("Query results:");
        for (Map<String, Object> row : rows) {
            System.out.println(row);
        }
    }
}
