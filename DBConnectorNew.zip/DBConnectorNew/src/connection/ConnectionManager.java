package connection;

import config.DBConfig;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
    private final DBConfig dbConfig;

    public ConnectionManager(DBConfig dbConfig) {
        this.dbConfig = dbConfig;
    }
    public Connection getConnection(String dbName) throws SQLException, ClassNotFoundException {
    	Connection conn=null;
        DBConfig.DbEntry entry = dbConfig.getDbEntry(dbName);

        Class.forName(entry.getDriverClass());
        conn=DriverManager.getConnection(entry.getUrl(), entry.getUsername(), entry.getPassword());
        if(conn!=null) {
        	System.out.print("Connected succssfully");
        }
        return conn;
    }
}
